# Walmart Web & Dashboard Brand Guide

Complete specifications for applying Walmart brand guidelines to web applications, internal dashboards, and browser-based tools. Framework-agnostic — uses CSS custom properties (design tokens) that work with any stack.

## Table of Contents

1. [Design Tokens (CSS Custom Properties)](#design-tokens)
2. [Color Usage for Web](#color-usage-for-web)
3. [Typography for Web](#typography-for-web)
4. [Layout & Spacing](#layout--spacing)
5. [Components](#components)
6. [Dashboard-Specific Patterns](#dashboard-specific-patterns)
7. [Data Visualization](#data-visualization)
8. [Accessibility](#accessibility)
9. [Dark Mode](#dark-mode)
10. [Streamlit & Posit Theming](#streamlit--posit-shiny-theming)
11. [Don'ts Checklist](#donts-checklist)

---

## Design Tokens

Use these CSS custom properties as the single source of truth for all Walmart-branded web content. Paste this block into your root stylesheet or design token file:

```css
:root {
  /* Primary palette */
  --wm-true-blue: #0053E2;
  --wm-white: #FFFFFF;
  --wm-spark-yellow: #FFC220;

  /* Secondary palette */
  --wm-sky-blue: #A9DDF7;
  --wm-everyday-blue: #4DBDF5;
  --wm-bentonville-blue: #001E60;

  /* Semantic tokens — light mode (default) */
  --wm-bg-primary: #FFFFFF;
  --wm-bg-secondary: #F5F7FA;
  --wm-bg-accent: #0053E2;
  --wm-bg-accent-dark: #001E60;

  --wm-text-primary: #001E60;        /* Bentonville Blue — default text */
  --wm-text-secondary: #4A5568;      /* Muted text for captions, metadata */
  --wm-text-on-accent: #FFFFFF;      /* Text on blue backgrounds */
  --wm-text-link: #0053E2;           /* True Blue for links */
  --wm-text-link-hover: #001E60;     /* Bentonville Blue on hover */

  --wm-border-default: #E2E8F0;
  --wm-border-strong: #001E60;

  /* Typography */
  --wm-font-family: 'Everyday Sans', 'Calibri', 'Segoe UI', system-ui, sans-serif;
  --wm-font-mono: 'Everyday Sans Mono', 'SF Mono', 'Consolas', monospace;

  --wm-font-size-xs: 0.75rem;       /* 12px — captions, labels */
  --wm-font-size-sm: 0.875rem;      /* 14px — secondary text */
  --wm-font-size-base: 1rem;        /* 16px — body */
  --wm-font-size-lg: 1.25rem;       /* 20px — subheads */
  --wm-font-size-xl: 1.5rem;        /* 24px — section headers */
  --wm-font-size-2xl: 2rem;         /* 32px — page titles */
  --wm-font-size-3xl: 2.5rem;       /* 40px — hero headlines */

  --wm-leading-tight: 1.0;
  --wm-leading-normal: 1.2;
  --wm-leading-relaxed: 1.3;

  --wm-font-weight-regular: 400;
  --wm-font-weight-medium: 500;
  --wm-font-weight-bold: 700;

  /* Spacing (based on 8px grid) */
  --wm-space-1: 0.25rem;   /* 4px */
  --wm-space-2: 0.5rem;    /* 8px */
  --wm-space-3: 0.75rem;   /* 12px */
  --wm-space-4: 1rem;      /* 16px */
  --wm-space-6: 1.5rem;    /* 24px */
  --wm-space-8: 2rem;      /* 32px */
  --wm-space-10: 2.5rem;   /* 40px */
  --wm-space-12: 3rem;     /* 48px */
  --wm-space-16: 4rem;     /* 64px */

  /* Border radius */
  --wm-radius-sm: 4px;
  --wm-radius-md: 8px;
  --wm-radius-lg: 12px;
  --wm-radius-xl: 16px;
  --wm-radius-pill: 9999px;         /* Pill-shaped buttons */

  /* Shadows */
  --wm-shadow-sm: 0 1px 2px rgba(0, 30, 96, 0.05);
  --wm-shadow-md: 0 4px 6px rgba(0, 30, 96, 0.07);
  --wm-shadow-lg: 0 10px 15px rgba(0, 30, 96, 0.1);
}
```

---

## Color Usage for Web

### Default: Light Mode

Web apps and dashboards default to **light mode** (white backgrounds) — the same principle as presentations. Light mode is standard for everyday use, more print-friendly, and easier on the eyes during extended work sessions.

Only use dark/blue backgrounds when the user explicitly requests it, or for specific high-impact sections (hero banners, login screens).

### Backgrounds

| Surface | Token | Hex | When to use |
|---|---|---|---|
| Page background | `--wm-bg-primary` | `#FFFFFF` | Default for all pages and views |
| Card/panel background | `--wm-bg-secondary` | `#F5F7FA` | Subtle contrast for cards, sidebars, table headers |
| Accent section | `--wm-bg-accent` | `#0053E2` | Hero banners, CTAs, login screens — high-impact only |
| Dark accent | `--wm-bg-accent-dark` | `#001E60` | Navigation bars, footers, or when explicitly requested |

### Text

| Context | Token | Hex |
|---|---|---|
| Body text, headings | `--wm-text-primary` | `#001E60` (Bentonville Blue) |
| Secondary/muted text | `--wm-text-secondary` | `#4A5568` |
| Text on blue backgrounds | `--wm-text-on-accent` | `#FFFFFF` |
| Links | `--wm-text-link` | `#0053E2` (True Blue) |
| Link hover | `--wm-text-link-hover` | `#001E60` |

### Status Colors

For dashboards and apps that need success/warning/error states, use these alongside the brand palette:

| State | Suggested Color | Notes |
|---|---|---|
| Success | `#15803D` (green-700) | Use sparingly alongside brand blues |
| Warning | `#D97706` (amber-600) | Distinct from Spark Yellow to avoid brand confusion |
| Error/Danger | `#DC2626` (red-600) | Standard error red |
| Info | `#0053E2` (True Blue) | Reuse True Blue for informational states |

These status colors are functional — they're not part of the brand palette but are necessary for UI communication. Keep them in their functional role and don't use them decoratively.

---

## Typography for Web

### Type Scale

| Level | Size | Weight | Leading | Token | Usage |
|---|---|---|---|---|---|
| Hero headline | 2.5rem (40px) | Medium 500 | 1.0 | `--wm-font-size-3xl` | Landing pages, hero sections |
| Page title | 2rem (32px) | Medium 500 | 1.2 | `--wm-font-size-2xl` | Page headers, dashboard titles |
| Section header | 1.5rem (24px) | Medium 500 | 1.2 | `--wm-font-size-xl` | Section headings, card titles |
| Subhead | 1.25rem (20px) | Medium 500 | 1.2 | `--wm-font-size-lg` | Subsections, widget titles |
| Body | 1rem (16px) | Regular 400 | 1.2 | `--wm-font-size-base` | Paragraphs, descriptions |
| Secondary | 0.875rem (14px) | Regular 400 | 1.3 | `--wm-font-size-sm` | Table cells, form labels, metadata |
| Caption | 0.75rem (12px) | Regular 400 | 1.3 | `--wm-font-size-xs` | Timestamps, chart labels, fine print |

### Key Rules

- All text defaults to **Bentonville Blue** (`#001E60`) — not black. This is a core brand differentiator.
- Use the `--wm-font-family` token everywhere. Fall back to Calibri → system sans-serif if Everyday Sans isn't loaded.
- Use `--wm-font-mono` for data tables, code blocks, and numeric displays.
- Maintain at least a **2:1 size ratio** between page title and body text.
- No all-caps for headings. Title case for internal tools, sentence case for customer-facing apps.
- Never adjust letter-spacing (it's built into the typeface).
- Maximum line length: 70 characters for body text. Use `max-width` to enforce this.

---

## Layout & Spacing

### Spacing System

Use an **8px base grid**. All spacing (padding, margins, gaps) should be multiples of 8px, with 4px for tight adjustments. The design tokens above follow this grid.

### Page Layout

| Element | Spec |
|---|---|
| Max content width | 1280px (80rem) — center on wider screens |
| Page padding | `--wm-space-8` (32px) on desktop, `--wm-space-4` (16px) on mobile |
| Section spacing | `--wm-space-12` (48px) between major sections |
| Card padding | `--wm-space-6` (24px) |
| Card gap | `--wm-space-6` (24px) between cards in a grid |

### Grid

Use CSS Grid or Flexbox. For dashboard layouts, a **12-column grid** (matching the PPTX grid) provides consistency across mediums. Gutters should be `--wm-space-6` (24px).

---

## Components

### Buttons

All buttons are **pill-shaped** — use `border-radius: var(--wm-radius-pill)` (9999px).

```css
.wm-btn-primary {
  background-color: var(--wm-true-blue);
  color: var(--wm-white);
  border: none;
  border-radius: var(--wm-radius-pill);
  padding: var(--wm-space-3) var(--wm-space-6);
  font-family: var(--wm-font-family);
  font-weight: var(--wm-font-weight-medium);
  font-size: var(--wm-font-size-base);
  text-transform: none;  /* Never all-caps */
  cursor: pointer;
}

.wm-btn-secondary {
  background-color: transparent;
  color: var(--wm-bentonville-blue);
  border: 1.5px solid var(--wm-bentonville-blue);
  border-radius: var(--wm-radius-pill);
  padding: var(--wm-space-3) var(--wm-space-6);
  font-family: var(--wm-font-family);
  font-weight: var(--wm-font-weight-medium);
  font-size: var(--wm-font-size-base);
  text-transform: none;
  cursor: pointer;
}
```

- Default solid button: **True Blue** background, white text.
- On True Blue backgrounds: switch to **Everyday Blue** or white outline.
- Never use bold or all-caps on button text.
- Never use rectangular (sharp-cornered) buttons.

### Cards

```css
.wm-card {
  background: var(--wm-bg-primary);
  border: 1px solid var(--wm-border-default);
  border-radius: var(--wm-radius-lg);  /* 12px */
  padding: var(--wm-space-6);
  box-shadow: var(--wm-shadow-sm);
}
```

### Form Inputs

```css
.wm-input {
  border: 1.5px solid var(--wm-border-default);
  border-radius: var(--wm-radius-md);  /* 8px */
  padding: var(--wm-space-3) var(--wm-space-4);
  font-family: var(--wm-font-family);
  font-size: var(--wm-font-size-base);
  color: var(--wm-text-primary);
}

.wm-input:focus {
  border-color: var(--wm-true-blue);
  outline: 2px solid rgba(0, 83, 226, 0.2);
}
```

### Navigation

- Sidebar or top nav background: **Bentonville Blue** (`#001E60`) or **White** — choose one and stay consistent across the app.
- Nav text: White on dark nav, Bentonville Blue on white nav.
- Active/selected state: **True Blue** background or True Blue left-border indicator.
- Walmart Spark in the nav header area. Keep it small (16–24px minimum). Use `assets/walmart-spark.svg` (yellow) on white nav or `assets/walmart-spark-white.svg` on dark nav.

---

## Dashboard-Specific Patterns

### KPI Cards

```css
.wm-kpi-card {
  background: var(--wm-bg-primary);
  border: 1px solid var(--wm-border-default);
  border-radius: var(--wm-radius-lg);
  padding: var(--wm-space-6);
}

.wm-kpi-value {
  font-size: var(--wm-font-size-2xl);
  font-weight: var(--wm-font-weight-medium);
  color: var(--wm-text-primary);
}

.wm-kpi-label {
  font-size: var(--wm-font-size-sm);
  color: var(--wm-text-secondary);
  margin-top: var(--wm-space-1);
}
```

### Tables

| Element | Style |
|---|---|
| Header row | `--wm-bg-secondary` background, `--wm-font-weight-medium` text |
| Header text color | Bentonville Blue |
| Body text | Regular weight, Bentonville Blue |
| Row borders | 1px `--wm-border-default` |
| Alternating rows | Optional — use `--wm-bg-secondary` for zebra striping |
| Hover state | Subtle `--wm-bg-secondary` background |
| Numeric data | Use `--wm-font-mono` for alignment and readability |

### Sidebar Filters

- Background: `--wm-bg-secondary` or white
- Section headers: Medium weight, `--wm-font-size-sm`
- Filter controls: Standard form inputs with `--wm-radius-md`
- Active filters: True Blue pill badges

---

## Data Visualization

### Chart Color Sequence

Use the brand waterfall in this order when assigning colors to data series:

| Order | Color | Hex | Token |
|---|---|---|---|
| 1 | True Blue | `#0053E2` | `--wm-true-blue` |
| 2 | Everyday Blue | `#4DBDF5` | `--wm-everyday-blue` |
| 3 | Sky Blue | `#A9DDF7` | `--wm-sky-blue` |
| 4 | Bentonville Blue | `#001E60` | `--wm-bentonville-blue` |
| 5 | Spark Yellow | `#FFC220` | `--wm-spark-yellow` (accent only, use sparingly) |

For charts with more than 5 series, introduce opacity variations (e.g., True Blue at 60%, 40%) before adding off-brand colors.

### Chart Styling

- Axis labels and tick marks: `--wm-text-secondary`, `--wm-font-size-xs`
- Chart title: `--wm-text-primary`, `--wm-font-size-lg`, Medium weight
- Grid lines: Light `#E2E8F0` with low opacity
- Tooltips: White background, `--wm-shadow-md`, `--wm-radius-md` corners
- Legend text: `--wm-font-size-sm`, Regular weight

---

## Accessibility

Target: **WCAG 2.0 AAA** where possible, AA minimum.

### Contrast Requirements

| Text | Background | Result |
|---|---|---|
| Bentonville Blue `#001E60` | White `#FFFFFF` | AAA all sizes |
| Bentonville Blue `#001E60` | Sky Blue `#A9DDF7` | AAA all sizes |
| Bentonville Blue `#001E60` | Everyday Blue `#4DBDF5` | AAA all sizes |
| White `#FFFFFF` | Bentonville Blue `#001E60` | AAA all sizes |
| White `#FFFFFF` | True Blue `#0053E2` | AA all sizes (not AAA at small sizes) |

### Web-Specific Accessibility

- All interactive elements need visible focus indicators (the `:focus` styles above provide this).
- Minimum touch target: 44×44px for mobile, 32×32px for desktop.
- Don't rely on color alone to convey meaning — pair color with icons, labels, or patterns.
- All images and icons need alt text.
- Use semantic HTML (`<nav>`, `<main>`, `<header>`, `<table>`, etc.).

---

## Dark Mode

Dark mode is **not the default** — only implement when the user specifically requests it or the app has a toggle.

When dark mode is needed, override the semantic tokens:

```css
[data-theme="dark"], .wm-dark {
  --wm-bg-primary: #001E60;          /* Bentonville Blue */
  --wm-bg-secondary: #002A7A;        /* Slightly lighter than Bentonville */
  --wm-bg-accent: #0053E2;           /* True Blue */

  --wm-text-primary: #FFFFFF;
  --wm-text-secondary: #A9DDF7;      /* Sky Blue for muted text */
  --wm-text-on-accent: #FFFFFF;
  --wm-text-link: #4DBDF5;           /* Everyday Blue for links */
  --wm-text-link-hover: #A9DDF7;

  --wm-border-default: rgba(255, 255, 255, 0.15);
  --wm-border-strong: #FFFFFF;

  --wm-shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.2);
  --wm-shadow-md: 0 4px 6px rgba(0, 0, 0, 0.25);
  --wm-shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.3);
}
```

In dark mode, use Bentonville Blue as the base background — never pure black. This keeps the branded feel while providing sufficient contrast.

---

## Streamlit & Posit (Shiny) Theming

Your team uses Streamlit and Posit/Shiny for analytical dashboards. These frameworks have their own theming systems — here's how to apply Walmart branding in each.

### Streamlit

Create a `.streamlit/config.toml` file in the project root:

```toml
[theme]
primaryColor = "#0053E2"          # True Blue — buttons, widgets, accents
backgroundColor = "#FFFFFF"        # White — default light mode
secondaryBackgroundColor = "#F5F7FA"  # Light gray — sidebar, card backgrounds
textColor = "#001E60"              # Bentonville Blue — all text
font = "sans serif"                # Closest to Everyday Sans in Streamlit
```

Additional Streamlit tips:
- Use `st.markdown()` with custom CSS to override elements Streamlit doesn't expose through config (e.g., injecting `--wm-` tokens or pill-shaped buttons).
- For charts, configure Plotly/Altair/Matplotlib color sequences to use the brand waterfall: `["#0053E2", "#4DBDF5", "#A9DDF7", "#001E60", "#FFC220"]`.
- Add the Spark logo to the sidebar header with `st.sidebar.image()`.
- Use `st.metric()` for KPI cards — the default styling works well with the theme above.

### Posit / Shiny (R and Python)

For **Shiny for R** with `bslib`:

```r
library(bslib)

walmart_theme <- bs_theme(
  bg = "#FFFFFF",
  fg = "#001E60",
  primary = "#0053E2",
  secondary = "#A9DDF7",
  success = "#15803D",
  warning = "#D97706",
  danger = "#DC2626",
  info = "#4DBDF5",
  base_font = font_google("Inter"),  # Closest Google Font to Everyday Sans
  heading_font = font_google("Inter"),
  font_scale = 1.0,
  `enable-rounded` = TRUE
)

# Apply in UI
ui <- page_sidebar(
  theme = walmart_theme,
  ...
)
```

For **Shiny for Python**:

```python
from shiny import ui

walmart_theme = ui.Theme("shiny")
walmart_theme.add_defaults(
    primary="#0053E2",
    secondary="#A9DDF7",
    success="#15803D",
    warning="#D97706",
    danger="#DC2626",
    info="#4DBDF5",
    body_bg="#FFFFFF",
    body_color="#001E60",
)

app_ui = ui.page_sidebar(
    ui.sidebar(...),
    theme=walmart_theme,
)
```

### Chart Libraries

Regardless of framework, configure your chart libraries with the brand waterfall:

| Library | How to set colors |
|---|---|
| **Plotly** | `color_discrete_sequence=["#0053E2", "#4DBDF5", "#A9DDF7", "#001E60", "#FFC220"]` |
| **Altair** | `alt.Scale(range=["#0053E2", "#4DBDF5", "#A9DDF7", "#001E60", "#FFC220"])` |
| **Matplotlib** | `plt.rcParams['axes.prop_cycle'] = cycler(color=["#0053E2", "#4DBDF5", "#A9DDF7", "#001E60", "#FFC220"])` |
| **ggplot2** | `scale_color_manual(values = c("#0053E2", "#4DBDF5", "#A9DDF7", "#001E60", "#FFC220"))` |

---

## Don'ts Checklist

Use this when reviewing web apps and dashboards:

**Colors**: Don't use black (`#000000`) for text — always Bentonville Blue. Don't use Spark Yellow for anything except the Spark logo. Don't use True Blue for body text. Don't introduce off-brand colors when the brand palette can serve the purpose.

**Typography**: Don't use a different font family. Don't use all-caps headings. Don't adjust letter-spacing. Don't use font weights outside the approved set (Regular, Medium, Bold). Don't use Black weight.

**Buttons**: Don't use rectangular buttons — always pill-shaped. Don't use bold or all-caps text on buttons.

**Layout**: Don't use spacing values that aren't multiples of 4/8px. Don't exceed 70-character line widths for body text.

**Logo**: Don't place wordmark without Spark in the same UI. Don't resize below minimums (16px for Spark, 24px for wordmark). Don't recolor or animate the logo elements.

**Charts**: Don't use off-brand colors when the waterfall palette suffices. Don't use Spark Yellow as a primary data color (accent only). Don't skip the established color sequence order.
