# Walmart DOCX Brand Guide

Complete specifications for creating and reviewing Walmart-branded Word documents.

## Table of Contents

1. [Page Setup](#page-setup)
2. [Color Palette](#color-palette)
3. [Typography](#typography)
4. [Layout & Grid](#layout--grid)
5. [Logo Placement](#logo-placement)
6. [Frames & Corner Radius](#frames--corner-radius)
7. [Accessibility](#accessibility)
8. [Voice & Copy](#voice--copy)
9. [Don'ts Checklist](#donts-checklist)

---

## Page Setup

| Setting | Value |
|---|---|
| Page size | **8.5 × 11 inches** (letter) |
| Margins | **0.5 inches** all four sides |
| Column grid | **6 columns** (for complex multi-column layouts) |

The margin formula is: longest side ÷ 24. For an 11-inch long side: 11 ÷ 24 ≈ 0.46 in, rounded to **0.5 in** for practicality.

---

## Color Palette

### Primary Colors

| Name | Hex | RGB | CMYK | Usage |
|---|---|---|---|---|
| **True Blue** | `#0053E2` | (0, 83, 226) | C99 M76 Y0 K0 | High-impact elements only: cover pages, section headers. Never for body text. |
| **White** | `#FFFFFF` | (255, 255, 255) | C0 M0 Y0 K0 | Page backgrounds. Text on blue backgrounds. |
| **Spark Yellow** | `#FFC220` | (255, 194, 32) | C0 M22 Y94 K0 | Spark logo only. Never for text or decorative use. |

### Secondary Colors

| Name | Hex | RGB | CMYK | Usage |
|---|---|---|---|---|
| **Sky Blue** | `#A9DDF7` | (169, 221, 247) | C22 M0 Y0 K0 | Charts, tables, data hierarchy. |
| **Everyday Blue** | `#4DBDF5` | (77, 189, 245) | C52 M0 Y0 K0 | Charts, tables, data hierarchy. |
| **Bentonville Blue** | `#001E60` | (0, 30, 96) | C100 M81 Y0 K51 | **Primary text color** — all body copy, headlines, and standard text. |

### Chart/Table Color Waterfall

1. White `#FFFFFF`
2. Sky Blue `#A9DDF7`
3. Everyday Blue `#4DBDF5`
4. True Blue `#0053E2`
5. Bentonville Blue `#001E60`

---

## Typography

### Typeface

**Everyday Sans** — Walmart's custom type family. For print/PDF documents, CMYK values are provided above. If Everyday Sans is unavailable, use Calibri as a fallback.

### Weights and Usage

| Weight | Usage in DOCX |
|---|---|
| **Light** | XL headlines only (Everyday Sans Headline variant); rarely needed in standard docs |
| **Regular** | Body copy, captions, legal text |
| **Medium** | Headlines, subheads |
| **Bold** | Inline headers within body text |
| **Black** | Never use in standard documents |

### Type Hierarchy

| Level | Font & Weight | Leading | Tracking | Relative Scale |
|---|---|---|---|---|
| Headline | Everyday Sans, Medium | 1.2× | 0 | 4× body |
| Subhead | Everyday Sans, Medium | 1.2× | 0 | 2× body |
| Inline Header | Everyday Sans, Bold | 1.2× | 0 | 1× body |
| Body Copy | Everyday Sans, Regular | 1.2× | 0 | 1× (base) |
| Captions & Legal | Everyday Sans, Regular | 1.3× | 0 | 1× body |
| Data & Code | Everyday Sans Mono, Regular | 1.3× | 0 | 1× body |

### Practical Font Sizing (suggested for 8.5 × 11 in documents)

| Level | Approx. Size |
|---|---|
| Headline | 24–30 pt |
| Subhead | 14–16 pt |
| Body | 10–12 pt |
| Captions/Legal | 8–9 pt |

### Key Typography Rules

- Maintain at least a **2:1 size ratio** between headline and subhead.
- **Title Case** for internal documents (reports, memos). **Sentence case** for customer-facing materials.
- Never use **all-caps** for headlines or subheads.
- Never adjust letter spacing (tracking) — it's designed into the typeface.
- Body text color: always **Bentonville Blue** (`#001E60`).
- On True Blue or Bentonville Blue backgrounds (e.g., cover pages): use **White** text.
- Keep body copy to **40–70 characters per line**. If content is wider, use columns.
- Keep headlines to **4–15 words per line**.
- Leading formula: type size (pt) × leading ratio = line spacing (pt). Example: 12 pt body × 1.2 = 14.4 pt line spacing.

---

## Layout & Grid

### Grid Setup

1. Set all four margins to **0.5 inches**.
2. For complex layouts (multi-column pages), divide into **6 columns** with proportional gutters.
3. Simple documents (single-column body text) don't need an explicit column grid — just respect margins and line lengths.

### Headline Placement

- Place main headlines prominently at the top of the page or section.
- Maintain at least a **3:2 height ratio** between headline and wordmark when both appear on the same page (e.g., cover page).

### Subhead Rules

- Subhead cap height: maximum **50% of headline cap height**.
- Minimum space between headline and subhead: **¾ of headline height**.
- Left-aligned, stacked beneath headline.

---

## Logo Placement

The wordmark and Spark are **decoupled** — placed separately, on opposite sides of the layout.

**Logo assets** are bundled in the `assets/` directory:
- `assets/walmart-spark.svg` / `.png` — Spark Yellow, for white/light page backgrounds
- `assets/walmart-spark-white.svg` / `.png` — White, for blue/dark cover pages

Use SVG when possible; fall back to PNG when the tool doesn't support SVG.

### Document Contexts

| Context | Wordmark | Spark |
|---|---|---|
| **Cover page** | Lower-left, aligned to margin | Upper-right (diagonal) |
| **Header/Footer** | Lower-left of footer or upper-left of header | Opposite corner from wordmark |
| **Interior pages** | Footer or omit (Spark on each page is optional) | If present, opposite side from wordmark |

### Size Rules

- Wordmark minimum size: **0.25 in** standard / **0.15 in** for small-use contexts.
- Spark minimum size: **0.25 in**.
- Spark height = **1.7× the height of the wordmark**.

### Color Rules

| Background | Wordmark | Spark |
|---|---|---|
| White page | True Blue | Spark Yellow |
| True Blue page (cover) | White | Spark Yellow |
| Bentonville Blue page | White | Spark Yellow |

### Logo Don'ts

- Never place wordmark on the right edge or top margin.
- Never combine wordmark and Spark into a lockup.
- Never use wordmark without Spark present in the same layout.
- Never use unapproved colors, partial transparency, cropping, rotation, or skewing.

---

## Frames & Corner Radius

### Corner Radius

Formula: **longest side ÷ 15**. For 8.5 × 11 in documents (11 in = longest side): 11 ÷ 15 ≈ **0.73 in** corner radius on frames and image containers.

When multiple frames appear, use a consistent corner radius across all (average if needed).

### Outline Weight

Formula: **longest side ÷ 150**. For 11-inch documents: approximately **0.5 pt** stroke weight.

### Frame Types

| Type | Description | Max per page |
|---|---|---|
| **Window** | Holds photography. Aligns to grid, can bleed off edges. | 3 |
| **Tile** | Grounds isolated products. Can float. | 5 |
| **Outline** | Focal emphasis. Stroke in White or Bentonville Blue only. | 1 |

### Frame Rules

- Less is more. Frames are functional, not decorative.
- Leave clear space equal to the margin between frames and adjacent content.
- Don't nest, overlap, or collage frames.
- Don't mix all frame types on one page.

---

## Accessibility

Target: **WCAG 2.0 AAA**.

### Compliant Text/Background Pairings

| Text | Background | Compliance |
|---|---|---|
| Bentonville Blue `#001E60` | White `#FFFFFF` | AAA (all sizes) |
| Bentonville Blue `#001E60` | Sky Blue `#A9DDF7` | AAA (all sizes) |
| Bentonville Blue `#001E60` | Everyday Blue `#4DBDF5` | AAA (all sizes) |
| Bentonville Blue `#001E60` | Spark Yellow `#FFC220` | AAA (all sizes) |
| White `#FFFFFF` | Bentonville Blue `#001E60` | AAA (all sizes) |

True Blue (`#0053E2`) text is NOT AAA-compliant at small sizes — only use for large display text.

---

## Voice & Copy

### Principles

| Principle | Tone |
|---|---|
| **Conversational** | Down-to-earth, relatable. Simple words, clear sentences. |
| **Captivating** | Dynamic and energizing. Wordplay, subtle rhymes, punchy structures. |
| **Confident** | Decisive and inspiring. Specific and direct. |

### Copy Rules for Documents

- Clarity first. Every paragraph should serve a purpose.
- No puns.
- Humor: observational and relatable only, and generally not appropriate for formal reports.
- Title case for internal documents. Sentence case for external/customer-facing.
- Value messaging: find fresh ways to convey value — avoid tired phrases.
- Body copy: 40–70 characters per line. Break into columns if wider.

---

## Don'ts Checklist

Use this when reviewing documents:

**Colors**: Don't use unapproved colors. Don't use the wordmark at partial opacity. Don't combine too many type colors in one layout.

**Typography**: Don't use Everyday Sans Mono for headlines. Don't use unapproved weights. Don't set type levels too close in size. Don't increase letter spacing. Don't use all-caps for headlines. Don't use low-contrast text pairings.

**Frames**: Don't nest or overlap. Don't use multiple outlines per page. Don't use frames as decoration.

**Logo**: Don't align wordmark to right or top. Don't lock up wordmark + Spark. Don't omit the Spark when wordmark is present. Don't crop, rotate, or recolor.
