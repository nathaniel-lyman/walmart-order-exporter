# Walmart PPTX Brand Guide

Complete specifications for creating and reviewing Walmart-branded PowerPoint presentations.

## Table of Contents

1. [Slide Setup](#slide-setup)
2. [Color Palette](#color-palette)
3. [Typography](#typography)
4. [Layout & Grid](#layout--grid)
5. [Logo Placement](#logo-placement)
6. [Frames & Corner Radius](#frames--corner-radius)
7. [Buttons](#buttons)
8. [Accessibility](#accessibility)
9. [Voice & Copy](#voice--copy)
10. [Don'ts Checklist](#donts-checklist)

---

## Slide Setup

| Setting | Value |
|---|---|
| Slide width | **13.33 inches** (1920 px) |
| Slide height | **7.5 inches** (1080 px) |
| Aspect ratio | 16:9 widescreen |
| Margins | **0.56 in (80 px)** all four sides |
| Column grid | **12 columns** with proportional gutters |

The margin formula is: longest side ÷ 24. For a 1920 px wide slide: 1920 ÷ 24 = 80 px = 0.56 in.

When setting up a new presentation in python-pptx or similar tools, explicitly set the slide dimensions to 13.33 × 7.5 inches. Do not rely on defaults.

### Default Background

Default to **white slide backgrounds** for all slides. White backgrounds are print-friendly, accessible, and the standard for everyday Walmart presentations. Blue backgrounds (True Blue or Bentonville Blue) are high-impact treatments reserved for title slides, section dividers, and end cards — only use them when the user explicitly asks for dark or blue slides. If the user doesn't specify a background preference, always go with white.

---

## Color Palette

### Primary Colors

| Name | Hex | RGB | Usage |
|---|---|---|---|
| **True Blue** | `#0053E2` | (0, 83, 226) | Primary brand blue. Use for slide backgrounds, high-impact/low-content slides (title slides, end cards, section dividers). Never use for dense body text — it fails AAA contrast at small sizes. |
| **White** | `#FFFFFF` | (255, 255, 255) | Text on blue backgrounds. Clean slide backgrounds. |
| **Spark Yellow** | `#FFC220` | (255, 194, 32) | Spark logo only. Never use for text, backgrounds, or decorative elements. |

### Secondary Colors (Accent Blues)

| Name | Hex | RGB | Usage |
|---|---|---|---|
| **Sky Blue** | `#A9DDF7` | (169, 221, 247) | Charts, graphs, data hierarchy tier 2. |
| **Everyday Blue** | `#4DBDF5` | (77, 189, 245) | Charts, graphs, data hierarchy tier 3. Buttons when placed on True Blue backgrounds. |
| **Bentonville Blue** | `#001E60` | (0, 30, 96) | **Primary typography color** — use for all body copy, headlines, and standard text. Also used for dark slide backgrounds. |

### Chart/Graph Waterfall Hierarchy

When coloring data in charts, use this progression from lightest to darkest:

1. White `#FFFFFF`
2. Sky Blue `#A9DDF7`
3. Everyday Blue `#4DBDF5`
4. True Blue `#0053E2`
5. Bentonville Blue `#001E60`

### Approved Background/Text Pairings

| Background | Text Color | Wordmark | Spark | Notes |
|---|---|---|---|---|
| **White** | Bentonville Blue | True Blue | Spark Yellow | **Default — use this unless told otherwise** |
| True Blue | White | White | Spark Yellow | High-impact only (title, divider, end card) — requires explicit user request |
| Bentonville Blue | White | White | Spark Yellow | High-impact only — requires explicit user request |
| Dark photography | White | White | White | |
| Light photography | True Blue (judgment call) | True Blue | Spark Yellow | |

---

## Typography

### Typeface

**Everyday Sans** — Walmart's custom type family. If unavailable, use a clean geometric sans-serif (Calibri is the closest common fallback).

### Weights and Usage

| Weight | Usage in PPTX |
|---|---|
| **Light** | XL headlines only (Everyday Sans Headline variant) |
| **Regular** | Body copy, captions, legal text |
| **Medium** | Headlines, subheads |
| **Bold** | Inline headers within body text |
| **Black** | Never use in standard presentations (reserved for swag/patches) |

### Type Hierarchy for Slides

| Level | Font & Weight | Leading | Tracking | Relative Scale |
|---|---|---|---|---|
| XL Headline | Everyday Sans Headline, Light | 1.0× | −15 | 5× body |
| Headline | Everyday Sans, Medium | 1.2× | 0 | 4× body |
| Subhead | Everyday Sans, Medium | 1.2× | 0 | 2× body |
| Inline Header | Everyday Sans, Bold | 1.2× | 0 | 1× body |
| Body Copy | Everyday Sans, Regular | 1.2× | 0 | 1× (base) |
| Captions & Legal | Everyday Sans, Regular | 1.3× | 0 | 1× body |

### Practical Font Sizing (suggested for 13.33 × 7.5 in slides)

These are guidelines — adapt to content density:

| Level | Approx. Size |
|---|---|
| XL Headline | 60–80 pt |
| Headline | 36–48 pt |
| Subhead | 20–24 pt |
| Body | 14–16 pt |
| Captions | 10–12 pt |

### Key Typography Rules

- Maintain at least a **2:1 size ratio** between headline and subhead.
- Use **Title Case** for internal presentations, **sentence case** for external/customer-facing.
- Never use **all-caps** for headlines or subheads.
- Never adjust letter spacing (tracking) except on XL headlines where −15 is acceptable.
- Body copy color is always **Bentonville Blue** (`#001E60`).
- On True Blue or Bentonville Blue backgrounds, text is always **White**.
- True Blue (`#0053E2`) may be used for headline text only on white backgrounds in high-impact, low-content slides — never for body text.
- Keep headline lines to **4–15 words**. Body copy lines to **40–70 characters**.

---

## Layout & Grid

### Grid Setup

1. Set all four margins to **0.56 in (80 px)**.
2. Divide the content area into **12 columns** with proportional gutters.
3. Gutters should feel proportional to column width — neither too narrow nor too wide.

### Headline Placement

- Primary headline position: **upper-left corner** of the slide.
- Headline-to-wordmark height ratio: at least **3:2** (headline should be noticeably larger).

### Subhead Placement

- Max cap height: **50% of headline's cap height**.
- Minimum space between headline and subhead: **¾ of the headline height**.
- Left-aligned, stacked beneath headline.

### Layout Quick Guide

1. Set margins: 0.56 in all sides
2. Set up 12 columns with proportional gutters
3. Place headline upper-left, large and impactful
4. Stack subhead below headline (≤50% of headline cap height)
5. Place Spark upper-right, Wordmark lower-left
6. Leave the last column free for Spark spacing

---

## Logo Placement

The Walmart wordmark and Spark are **always decoupled** — they go on opposite sides of the layout, never combined into a lockup.

**Logo assets** are bundled in the `assets/` directory:
- `assets/walmart-spark.svg` / `.png` — Spark Yellow, for white/light backgrounds
- `assets/walmart-spark-white.svg` / `.png` — White, for blue/dark backgrounds

Use the SVG when possible (scales cleanly to any size). Fall back to PNG when the tool doesn't support SVG.

### Primary Placement (preferred)

- **Wordmark**: lower-left, aligned precisely to the margin.
- **Spark**: upper-right corner (diagonal from wordmark).

### Size Relationships

- **Spark height** = 1.7× the height of the wordmark.
- **Wordmark height** = width of the margin (0.56 in / 80 px on standard slides).

### Placement Options (in preference order)

1. Left-aligned diagonal (wordmark bottom-left, Spark top-right) — **default**
2. Left-aligned vertical
3. Baseline horizontal
4. Centered vertical

### Color Rules

| Background | Wordmark Color | Spark Color |
|---|---|---|
| White | True Blue | Spark Yellow |
| True Blue | White | Spark Yellow |
| Bentonville Blue | White | Spark Yellow |
| Dark photography | White | White |
| Light photography | True Blue | Spark Yellow |

### Logo Don'ts

- Never align wordmark to the right edge or top margin.
- Never alter the size relationship between wordmark and Spark.
- Never create a lockup (wordmark + Spark combined left, above, or right).
- Never use the wordmark without the Spark present in the same layout.
- Never use unapproved colors, partial transparency, cropping, rotation, or skewing on either logo element.

---

## Frames & Corner Radius

### Corner Radius

Formula: **longest side ÷ 15 = corner radius**.

For standard 13.33 × 7.5 in slides: **30 px** corner radius on all frames.

When multiple frames appear, all corner radii should match (use the average if frames differ in size).

### Outline (Stroke) Weight

Formula: **longest side ÷ 150 = stroke weight**.

For standard slides: **1 pt** stroke weight.

### Frame Types

| Type | Description | Max per slide |
|---|---|---|
| **Window** | Holds photography/footage. Aligns to grid, can bleed off 1–2 opposite edges. | 3 |
| **Tile** | Grounds isolated products. Mimics digital shopping tiles. Can float center. | 5 |
| **Outline** | Emphasizes a focal point over photography. Stroke in White or Bentonville Blue only. | 1 |

### Frame Rules

- Less is more — minimize frames per layout.
- Frames are functional, not decorative.
- Leave clear space equal to the margin between frames and content.

### Frame Don'ts

- Don't nest frames within other frames.
- Don't collage or overlap frames.
- Don't use multiple outlines per layout.
- Don't mix all frame styles together on one slide.
- Don't use solid frames as decorative elements behind text.
- Don't use outlines as decorative borders around text blocks.
- Outline strokes: Bentonville Blue or White only.

---

## Buttons

All buttons are **pill-shaped** with fully rounded ends (full-radius corners). Never use rectangular buttons.

| Type | Purpose |
|---|---|
| **CTA** | Replaces standard typeset CTAs. Sized to match wordmark height. |
| **Action** | Pairs with photos for product stories. Max 3 per layout. |
| **Search** | Mimics Walmart.com search bar. Lowercase, solid white or outlined. |
| **Accent** | Corner of tiles/outlined frames. Enhances digital shopping feel. |

### Button Colors

- Default solid: **True Blue** (`#0053E2`).
- On True Blue backgrounds: switch to **Everyday Blue** (`#4DBDF5`).
- Solid search buttons: **White only**.
- Outlined buttons: **Bentonville Blue** or **White** only.

### Button Don'ts

- Don't use rectangular buttons.
- Don't set button text in bold or all-caps.

---

## Accessibility

Walmart targets **WCAG 2.0 AAA** compliance for text.

### AAA-Compliant Pairings (all sizes)

| Text | Background |
|---|---|
| Bentonville Blue `#001E60` | White `#FFFFFF` |
| Bentonville Blue `#001E60` | Sky Blue `#A9DDF7` |
| Bentonville Blue `#001E60` | Everyday Blue `#4DBDF5` |
| Bentonville Blue `#001E60` | Spark Yellow `#FFC220` |
| White `#FFFFFF` | Bentonville Blue `#001E60` |

**Note**: True Blue (`#0053E2`) text is NOT AAA-compliant at small sizes. Use it only for large headlines on white backgrounds.

---

## Voice & Copy

### Principles

| Principle | Derived From | Tone |
|---|---|---|
| **Conversational** | Grassroots | Down-to-earth, relatable. Simple words, clear sentences. |
| **Captivating** | Agile | Dynamic and energizing. Wordplay, subtle rhymes, punchy structures. |
| **Confident** | Pioneering | Decisive and inspiring. Specific and direct. |

### Copy Rules for Slides

- Clarity is paramount — every slide must communicate its point immediately.
- Find fresh ways to convey value (don't fall back on clichés).
- No puns.
- Humor: observational and relatable only, and generally reserved for social channels, not presentations.
- Title case for internal presentations. Sentence case for external/customer-facing.

---

## Don'ts Checklist

A consolidated list of things to avoid. Use this when reviewing slides:

**Colors**: Don't use the wordmark in unapproved colors or at partial opacity. Don't use low-contrast combos. Don't combine too many type colors in a single layout. Don't recolor individual sparklets.

**Typography**: Don't set headlines in Everyday Sans Mono. Don't use unapproved weights for subheads. Don't set type levels too close in size. Don't increase letter spacing. Don't use all-caps for headlines or subheads. Don't use low-contrast text/background combos.

**Frames**: Don't nest, overlap, or collage frames. Don't use multiple outlines per slide. Don't mix all frame types. Don't use frames as purely decorative elements.

**Buttons**: Don't use rectangular shapes. Don't use bold or all-caps button text.

**Logo**: Don't align wordmark to right or top. Don't create wordmark-Spark lockups. Don't use without the Spark. Don't crop, rotate, recolor, or skew either element.
