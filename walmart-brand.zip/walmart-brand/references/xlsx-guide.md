# Walmart XLSX Brand Guide

Complete specifications for applying Walmart brand guidelines to Excel spreadsheets — reports, data tables, financial models, and dashboards.

## Table of Contents

1. [General Principles](#general-principles)
2. [Color Palette for Spreadsheets](#color-palette-for-spreadsheets)
3. [Typography](#typography)
4. [Cell & Table Formatting](#cell--table-formatting)
5. [Header & Title Rows](#header--title-rows)
6. [Data Tables](#data-tables)
7. [Charts & Graphs](#charts--graphs)
8. [Conditional Formatting](#conditional-formatting)
9. [Sheet Layout & Structure](#sheet-layout--structure)
10. [Print Setup](#print-setup)
11. [Don'ts Checklist](#donts-checklist)

---

## General Principles

Walmart-branded spreadsheets should feel clean, professional, and immediately readable. The brand guidelines translate to Excel through consistent use of the color palette, clear typography hierarchy, and structured layouts. The goal isn't to make a spreadsheet look like a slide deck — it's to make data feel distinctly Walmart while remaining highly functional.

Key principles:
- **Clarity over decoration** — spreadsheets are tools, not marketing materials. Keep formatting purposeful.
- **White backgrounds by default** — same as presentations and web. Light, printable, easy on the eyes.
- **Bentonville Blue for text** — never use default Excel black. This is the single most visible brand differentiator in spreadsheets.
- **Brand colors for structure, not fill** — use color to create hierarchy (headers, sections, charts), not to fill every cell.

---

## Color Palette for Spreadsheets

### Primary Usage

| Color | Hex | RGB | Excel Use |
|---|---|---|---|
| **Bentonville Blue** | `#001E60` | (0, 30, 96) | All text — body, headers, labels. Primary header row background. |
| **White** | `#FFFFFF` | (255, 255, 255) | Cell backgrounds (default). Text on dark header rows. |
| **True Blue** | `#0053E2` | (0, 83, 226) | Title row background. Hyperlinks. Chart primary color. |

### Secondary / Accent Usage

| Color | Hex | RGB | Excel Use |
|---|---|---|---|
| **Sky Blue** | `#A9DDF7` | (169, 221, 247) | Alternating row shading. Subtotal row highlights. Chart tier 2. |
| **Everyday Blue** | `#4DBDF5` | (77, 189, 245) | Chart tier 3. Secondary accent in conditional formatting. |
| **Spark Yellow** | `#FFC220` | (255, 194, 32) | Highlight/callout cells only (sparingly). Never for text or large fills. |

### Light Tint for Cell Fills

For subtle alternating rows or section backgrounds, use light tints rather than full-strength brand colors:

| Purpose | Color | Hex | How to Achieve |
|---|---|---|---|
| Alternating row fill | Sky Blue 20% | `#EAF4FD` | Sky Blue at ~20% opacity on white |
| Section group fill | Sky Blue 10% | `#F4FAFF` | Very light wash for grouping |
| Highlight cell | Spark Yellow 20% | `#FFF9E6` | Subtle callout, not overwhelming |

---

## Typography

### Font

Use **Everyday Sans** if available. If not, use **Calibri** (Excel's default, and the closest standard match to Everyday Sans).

Never use Arial, Times New Roman, or other non-brand fonts in Walmart-branded workbooks.

### Type Hierarchy

| Level | Font | Size | Weight | Color | Usage |
|---|---|---|---|---|---|
| Workbook title | Calibri / Everyday Sans | 16–18 pt | Bold | Bentonville Blue `#001E60` | Sheet title row, top of report |
| Section header | Calibri / Everyday Sans | 13–14 pt | Bold | Bentonville Blue `#001E60` | Major section breaks |
| Column header | Calibri / Everyday Sans | 11 pt | Bold | White `#FFFFFF` (on dark fill) or Bentonville Blue (on light fill) | Table header row |
| Body / data | Calibri / Everyday Sans | 10–11 pt | Regular | Bentonville Blue `#001E60` | All cell data |
| Subtotal / total | Calibri / Everyday Sans | 10–11 pt | Bold | Bentonville Blue `#001E60` | Aggregation rows |
| Footnotes / source | Calibri / Everyday Sans | 8–9 pt | Regular | Bentonville Blue `#001E60` | Below tables, citations |

### Key Rules

- All text color is **Bentonville Blue** (`#001E60`) — not Excel's default black.
- White text only on dark-filled header rows (Bentonville Blue or True Blue backgrounds).
- Never use all-caps for headers. Use Title Case for column headers and section headers.
- No decorative fonts or font mixing within a single workbook.

---

## Cell & Table Formatting

### Borders

| Element | Style |
|---|---|
| Table outer border | Thin, Bentonville Blue `#001E60` |
| Column header bottom border | Medium, Bentonville Blue `#001E60` |
| Interior cell borders | Thin, light gray `#D1D5DB` or `#E2E8F0` |
| Subtotal/total row top border | Medium, Bentonville Blue `#001E60` |
| Subtotal/total row bottom border | Double, Bentonville Blue `#001E60` (for grand totals) |

### Cell Padding

Excel doesn't have true padding, but you can simulate it:
- Indent text 1 space from the left edge for data cells.
- Use a slightly taller row height for header rows (20–24 pt) vs. data rows (15–18 pt).
- Add a blank row between sections for visual breathing room.

### Number Formatting

| Data Type | Format | Example |
|---|---|---|
| Currency | `$#,##0` or `$#,##0.00` | $1,234 or $1,234.56 |
| Percentages | `0.0%` or `0%` | 12.5% |
| Large numbers | `#,##0` | 1,234,567 |
| Dates | `MMM DD, YYYY` or `MM/DD/YYYY` | Jan 15, 2026 |
| Negative numbers | Red `#DC2626` or parentheses `(1,234)` | Standard accounting convention |

---

## Header & Title Rows

### Title Row (Row 1)

| Property | Spec |
|---|---|
| Background | True Blue `#0053E2` or Bentonville Blue `#001E60` |
| Text | White, 16–18 pt, Bold |
| Content | Report name, date range, or workbook purpose |
| Row height | 30–36 pt |
| Merge | Merge across the full data width |

### Column Header Row

| Property | Spec |
|---|---|
| Background | Bentonville Blue `#001E60` |
| Text | White, 11 pt, Bold, Title Case |
| Bottom border | Medium, Bentonville Blue |
| Row height | 20–24 pt |
| Wrap text | Enable for long column names |
| Alignment | Left for text, right for numbers, center for dates/categories |

### Alternative: Light Header Style

For less formal or internal working spreadsheets:

| Property | Spec |
|---|---|
| Background | White or Sky Blue 20% `#EAF4FD` |
| Text | Bentonville Blue `#001E60`, 11 pt, Bold |
| Bottom border | Medium, Bentonville Blue |

---

## Data Tables

### Standard Table Pattern

```
┌──────────────────────────────────────────────┐
│  Report Title (True Blue bg, white text)      │  ← Title row
├──────────────────────────────────────────────┤
│  Col A  │  Col B  │  Col C  │  Col D         │  ← Header row (Bentonville Blue bg, white text)
├──────────────────────────────────────────────┤
│  data   │  data   │  data   │  data          │  ← Data rows (white bg)
│  data   │  data   │  data   │  data          │  ← Alternating (Sky Blue 20% bg, optional)
│  data   │  data   │  data   │  data          │
├──────────────────────────────────────────────┤
│  Subtotal│         │         │  sum           │  ← Subtotal (bold, top border)
╞══════════════════════════════════════════════╡
│  Total  │         │         │  sum            │  ← Grand total (bold, double bottom border)
└──────────────────────────────────────────────┘
```

### Alternating Row Shading

Optional but recommended for readability on wide tables:
- Even rows: White `#FFFFFF`
- Odd rows: Sky Blue 20% `#EAF4FD`

Never use strong blue fills on data rows — keep them subtle.

### Frozen Panes

- Freeze the header row (and title row if present) so headers stay visible when scrolling.
- For wide spreadsheets, also freeze the first 1–2 identifier columns.

---

## Charts & Graphs

### Color Sequence

Use the brand waterfall for chart data series, in this order:

| Order | Color | Hex |
|---|---|---|
| 1 | True Blue | `#0053E2` |
| 2 | Everyday Blue | `#4DBDF5` |
| 3 | Sky Blue | `#A9DDF7` |
| 4 | Bentonville Blue | `#001E60` |
| 5 | Spark Yellow | `#FFC220` (accent only) |

For charts with more than 5 series, use opacity variations (True Blue at 60%, 40%) before adding non-brand colors.

### Chart Formatting

| Element | Spec |
|---|---|
| Chart title | Bentonville Blue, 13–14 pt, Bold |
| Axis labels | Bentonville Blue, 9–10 pt, Regular |
| Axis titles | Bentonville Blue, 10 pt, Bold |
| Gridlines | Light gray `#E2E8F0`, thin |
| Legend | Bentonville Blue text, 9–10 pt, positioned bottom or right |
| Data labels | Bentonville Blue, 9 pt (use sparingly — only when they add clarity) |
| Chart background | White (no fill / transparent) |
| Plot area background | White |
| Chart border | None or thin light gray |

### Chart Types: Brand Alignment

| Chart Type | Notes |
|---|---|
| Bar/Column | Default choice for comparisons. Use brand waterfall colors. |
| Line | Good for trends. Use True Blue for primary series, Everyday Blue for secondary. |
| Pie/Donut | Use sparingly. Follow waterfall order. Max 5 slices before grouping into "Other." |
| Stacked | Follow waterfall order from bottom to top. |
| Scatter | True Blue dots, Bentonville Blue axis. |

---

## Conditional Formatting

### Approved Patterns

| Pattern | Colors | Usage |
|---|---|---|
| **Good / Neutral / Bad** | Green `#15803D` / Bentonville Blue / Red `#DC2626` | Performance against targets |
| **Heat map (brand)** | White → Sky Blue → Everyday Blue → True Blue → Bentonville Blue | Data density or magnitude |
| **Highlight exceptions** | Spark Yellow 20% `#FFF9E6` background | Flagging outliers or items needing attention |
| **Negative values** | Red `#DC2626` text or parentheses | Standard accounting |

### Rules

- Don't overuse conditional formatting — it should draw attention to what matters, not paint the entire sheet.
- Avoid red/green fills for accessibility (color blindness). Use red/green for text color with bold or icon markers as backup.
- Spark Yellow highlighting should be rare — it's a callout, not a category.

---

## Sheet Layout & Structure

### Workbook Organization

- **Cover/Summary sheet** (optional): Workbook title, date, author, table of contents linking to other sheets. Use the title row styling (True Blue bg, white text).
- **Data sheets**: One logical dataset per sheet. Name tabs clearly (e.g., "Q1 Revenue," "Store Metrics," not "Sheet1").
- **Reference/Lookup sheets**: Place at the end. Name with a prefix like "Ref_" or "Lookup_".

### Tab Colors

Use brand colors for sheet tab coloring:

| Tab Type | Color |
|---|---|
| Summary/Cover | True Blue `#0053E2` |
| Primary data sheets | Bentonville Blue `#001E60` |
| Secondary/supporting | Everyday Blue `#4DBDF5` |
| Reference/Lookup | Sky Blue `#A9DDF7` |

### Within Each Sheet

1. **Row 1**: Title row (merged, branded header)
2. **Row 2**: Blank spacer row (optional, for breathing room)
3. **Row 3**: Column headers (Bentonville Blue bg)
4. **Rows 4+**: Data
5. **After data**: Subtotals/totals, then footnotes/source notes

Leave **column A** empty (narrow, ~2 px wide) as a left margin. Start data in **column B**. Similarly, leave a narrow empty column after the last data column for visual padding.

---

## Print Setup

Walmart-branded spreadsheets should print cleanly:

| Setting | Spec |
|---|---|
| Orientation | Landscape for wide tables, Portrait for narrow |
| Margins | 0.5 in all sides (matching DOCX standard) |
| Header | Report title, left-aligned |
| Footer | Page number centered, date right-aligned |
| Repeat rows | Freeze title and column header rows for print |
| Scaling | Fit to page width, let length flow naturally |
| Gridlines | Print gridlines OFF (use formatted borders instead) |

---

## Don'ts Checklist

Use this when reviewing Walmart-branded spreadsheets:

**Colors**: Don't use Excel's default black for text — always Bentonville Blue. Don't use strong color fills on data rows (keep them light/subtle). Don't use Spark Yellow as a large-area fill. Don't use off-brand colors when the brand palette works.

**Typography**: Don't use Arial, Times New Roman, or other non-brand fonts. Don't use all-caps for headers. Don't mix more than one font family in a workbook. Don't use font sizes below 8 pt.

**Tables**: Don't leave raw unformatted data — always apply at least header styling and borders. Don't use Excel's built-in table styles (they use non-brand colors). Apply brand colors manually or via custom style.

**Charts**: Don't use Excel's default color palette — always override with the brand waterfall. Don't use 3D chart effects. Don't use chart backgrounds other than white. Don't add excessive gridlines or data labels.

**Layout**: Don't start data in cell A1 — leave a left margin column. Don't use multiple blank rows between sections (one is enough). Don't leave sheet tabs unnamed ("Sheet1", "Sheet2"). Don't use garish tab colors outside the brand palette.

**Conditional Formatting**: Don't apply conditional formatting to entire columns/rows unnecessarily. Don't use traffic-light fills (use text color + icons for accessibility). Don't use Spark Yellow as a status indicator (it's for callouts only).
