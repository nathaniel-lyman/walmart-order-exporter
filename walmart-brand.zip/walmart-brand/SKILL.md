---
name: walmart-brand
description: >
  Applies Walmart's official brand guidelines (colors, typography, layout, logo placement) to
  PPTX presentations, DOCX documents, web applications, and dashboards (including Streamlit and
  Posit/Shiny). Use this skill whenever creating, editing, or reviewing any Walmart-branded
  content. Trigger whenever the user mentions Walmart alongside presentations, slides, decks,
  documents, reports, memos, dashboards, web apps, Streamlit, Shiny, HTML, React, or brand
  review — even if they don't explicitly say "use brand guidelines." Also trigger when a user
  asks to review existing Walmart content for brand compliance, or asks brand reference questions
  like "what's the Walmart blue?" or "what font does Walmart use?"
---

# Walmart Brand Guidelines

This skill ensures every Walmart-branded output — presentations, documents, web apps, and dashboards — follows the official Walmart Brand Center standards. It covers colors, typography, layout grids, logo placement, frames, voice, and web-specific patterns including CSS design tokens and Streamlit/Posit theming. It also lets you review existing content for brand compliance.

## When This Skill Activates

- Creating a new Walmart presentation, document, web app, or dashboard
- Editing an existing Walmart-branded file or application
- Reviewing any Walmart content for brand compliance
- Building Streamlit or Posit/Shiny dashboards with Walmart branding
- Answering brand reference questions (colors, fonts, logo rules, design tokens)

## How to Use This Skill

### Step 1: Determine the task type

| User intent | Action |
|---|---|
| **Create** a new PPTX | Read `references/pptx-guide.md`, then build the file applying every spec |
| **Create** a new DOCX | Read `references/docx-guide.md`, then build the file applying every spec |
| **Create** a web app or dashboard | Read `references/web-guide.md`, then apply design tokens, component styles, and chart colors |
| **Create** a Streamlit or Posit/Shiny dashboard | Read `references/web-guide.md` (see the Streamlit & Posit section), then apply the framework-specific theme config |
| **Review** existing content | Read the appropriate guide, open the file/app, and check each element against the specs. Report violations with specific fixes. |
| **Brand question** | Answer from the quick reference below, or consult the full guide for edge cases |

### Step 2: Read the right reference file

Before creating or reviewing any file, always read the relevant reference:

- **For presentations**: Read `references/pptx-guide.md` — covers slide sizing, margins, grids, frame radii, logo placement, color usage, and typography for slides.
- **For documents**: Read `references/docx-guide.md` — covers page setup, margins, grids, typography hierarchy, and logo rules for Word docs.
- **For web apps & dashboards**: Read `references/web-guide.md` — covers CSS design tokens, component styles, data visualization colors, Streamlit/Posit theming, and dark mode.
- **For general brand questions**: Consult the quick reference below, or read the relevant guide for edge cases.

These reference files contain the complete, detailed specifications. The quick reference below is a summary for fast lookups — always defer to the full guides when building files.

## Quick Reference

### Colors

| Name | Hex | Role |
|---|---|---|
| **True Blue** | `#0053E2` | Primary brand blue. Backgrounds, high-impact headlines. Not for dense body text. |
| **Bentonville Blue** | `#001E60` | Primary text/body copy color. |
| **Spark Yellow** | `#FFC220` | Spark logo only. Never for text. |
| **White** | `#FFFFFF` | Text on blue backgrounds; clean backgrounds. |
| **Sky Blue** | `#A9DDF7` | Charts, accent tier 2. |
| **Everyday Blue** | `#4DBDF5` | Charts, accent tier 3. Buttons on True Blue bg. |

Chart color waterfall (tier 1→5): White → Sky Blue → Everyday Blue → True Blue → Bentonville Blue.

### Typography

**Typeface**: Everyday Sans (custom family). Fallback: a clean sans-serif like Calibri if Everyday Sans isn't available.

| Level | Weight | Leading |
|---|---|---|
| XL Headline | Headline variant, Light | 1.0× |
| Headline | Medium | 1.2× |
| Subhead | Medium | 1.2× |
| Inline Header | Bold | 1.2× |
| Body | Regular | 1.2× |
| Captions/Legal | Regular | 1.3× |

Key rules: minimum 2:1 size ratio between headline and subhead. Title case for internal docs, sentence case for external/customer-facing. Never use all-caps for headlines. Tracking is 0 everywhere except XL headlines (−15).

### PPTX Essentials

| Element | Spec |
|---|---|
| Slide size | **13.33 × 7.5 inches** widescreen (1920 × 1080 px, 16:9) |
| Margins | 0.56 in (80 px) all sides |
| Grid | 12 columns |
| Corner radius | 30 px |
| Stroke weight | 1 pt |
| Headline | Upper-left, at least 3:2 ratio to wordmark height |
| Wordmark | Lower-left, aligned to margin |
| Spark | Upper-right (diagonal from wordmark), 1.7× wordmark height |
| **Default background** | **White** — use white backgrounds unless the user explicitly requests dark/blue slides. White is print-friendly and the standard for everyday presentations. True Blue or Bentonville Blue backgrounds are reserved for high-impact moments (title slides, section dividers, end cards) and should only be used when specifically requested. |

### DOCX Essentials

| Element | Spec |
|---|---|
| Page size | 8.5 × 11 inches |
| Margins | 0.5 in all sides |
| Grid | 6 columns (for complex layouts) |
| Body text | Everyday Sans Regular, Bentonville Blue `#001E60` |
| Body line length | 40–70 characters per line |
| Headline line length | 4–15 words per line |

### Web & Dashboard Essentials

| Element | Spec |
|---|---|
| Default background | **White** — same as presentations, light mode is the default |
| Text color | Bentonville Blue `#001E60` (never black) |
| Link color | True Blue `#0053E2` |
| Buttons | Pill-shaped (`border-radius: 9999px`), True Blue solid default |
| Spacing grid | 8px base (all spacing in multiples of 4/8px) |
| Max content width | 1280px, centered |
| Chart color sequence | True Blue → Everyday Blue → Sky Blue → Bentonville Blue → Spark Yellow |
| Streamlit theme | Set `primaryColor="#0053E2"`, `textColor="#001E60"`, `backgroundColor="#FFFFFF"` in `.streamlit/config.toml` |
| Posit/Shiny theme | Use `bs_theme(primary="#0053E2", fg="#001E60", bg="#FFFFFF")` or Python equivalent |

### Logo Rules

- Wordmark and Spark are always **decoupled** — placed on opposite sides of a layout.
- Wordmark cannot appear without the Spark somewhere in the same layout.
- Primary placement: wordmark bottom-left, Spark top-right (diagonal).
- Spark height = 1.7× wordmark height. Wordmark height = margin width.
- Spark colors: Yellow on white/blue backgrounds; white over photography.
- Wordmark colors: True Blue on white, or white on blue/dark backgrounds.

### Voice

Three principles — **Conversational** (relatable, simple), **Captivating** (energizing, punchy), **Confident** (decisive, specific). No puns. Humor only observational and relatable. Clarity always comes first.

## Brand Compliance Review Checklist

When reviewing an existing Walmart document, check each of these:

1. **Colors** — Are only approved palette colors used? Is body text in Bentonville Blue? Is True Blue avoided for dense text?
2. **Typography** — Correct weights for each text level? Proper leading ratios? No all-caps headlines? Correct capitalization convention?
3. **Layout** — Correct margins and grid? Proper spacing between elements?
4. **Logo** — Wordmark and Spark both present? On opposite sides? Correct size relationship (1.7×)? Correct colors for the background?
5. **Frames** — Corner radii consistent? No nested/overlapping frames? Max counts respected (3 windows, 5 tiles, 1 outline)?
6. **Buttons** — Pill-shaped? Correct colors? No bold/all-caps button text?
7. **Voice** — Copy is clear, conversational, confident? No puns? Correct case convention?

Report each violation with the specific guideline it breaks and the recommended fix.

## Resources

### references/
- `pptx-guide.md` — Full PPTX creation and review specifications
- `docx-guide.md` — Full DOCX creation and review specifications
- `web-guide.md` — Full web app and dashboard specifications (CSS tokens, components, Streamlit/Posit theming, data viz, dark mode)

### assets/
- `walmart-spark.svg` — Official Spark logo in Spark Yellow (`#FFC220`), transparent background. Use for white/light backgrounds. (Source: Walmart Brand Center)
- `walmart-spark.png` — Official PNG raster of above. Use when SVG isn't supported.
- `walmart-spark-white.svg` — Spark logo in White, transparent background. Derived from official SVG. Use on True Blue, Bentonville Blue, or dark photography backgrounds.
- `walmart-spark-white.png` — PNG version of above.
